import sys
import numpy as np
import matplotlib.pyplot as plt
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QMessageBox, QGridLayout
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib
import sympy as sp
from math_keyboard import MathKeyboard
from func_utils import normalizar_expr, crear_funcion_con_lhopital

matplotlib.use("QtAgg")



# --- Aceleración de Aitken ---
def acelerar(x0, x1, x2):
    denom = x2 - 2*x1 + x0
    if denom == 0:
        raise ZeroDivisionError("División por cero en el método de Aitken.")
    return x0 - (x1 - x0)**2 / denom


def aitken(g, x0, tol, max_iter=100):
    x1 = g(x0)
    x2 = g(x1)
    pasos = [(0, x0, x1, x2, x0)]
    n = 0
    x_acelerado = x0
    tolerancia = tol + 1

    while tolerancia > tol and n < max_iter:
        n += 1
        x_anterior = x_acelerado
        x_acelerado = acelerar(x_acelerado, x1, x2)

        x1 = g(x_acelerado)
        x2 = g(x1)

        tolerancia = abs(x_acelerado - x_anterior)
        pasos.append((n, x_anterior, x1, x2, x_acelerado))

    if n == max_iter:
        raise ValueError("No converge en las iteraciones máximas")

    return x_acelerado, pasos


# --- Ventana principal ---
class AitkenWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Aceleración de Aitken")
        self.setGeometry(100, 100, 1000, 700)
        self.active_input = None

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        # --- Entradas ---
        form_layout = QHBoxLayout()
        layout.addLayout(form_layout)

        self.fx_input = QLineEdit("cos(x) - x")   # f(x)
        self.gx_input = QLineEdit("cos(x)")       # g(x)
        self.x0_input = QLineEdit("0.5")
        self.tol_input = QLineEdit("0.001")

        for entrada in [self.fx_input, self.gx_input, self.x0_input, self.tol_input]:
            entrada.installEventFilter(self)

        form_layout.addWidget(QLabel("f(x):"))
        form_layout.addWidget(self.fx_input)
        form_layout.addWidget(QLabel("g(x):"))
        form_layout.addWidget(self.gx_input)
        form_layout.addWidget(QLabel("x₀:"))
        form_layout.addWidget(self.x0_input)
        form_layout.addWidget(QLabel("Tolerancia:"))
        form_layout.addWidget(self.tol_input)

        # --- Teclado matemático ---
        self.keyboard = MathKeyboard(self.insertar_texto)
        layout.addWidget(self.keyboard)


        # --- Botón Calcular ---
        self.calc_btn = QPushButton("Calcular raíz (Aitken)")
        self.calc_btn.clicked.connect(self.calcular)
        layout.addWidget(self.calc_btn)

        # --- Área de gráfico ---
        self.figure, self.ax = plt.subplots(figsize=(8, 5))
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)

        # --- Salida de texto ---
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output)

    def eventFilter(self, obj, event):
        if event.type() == event.Type.FocusIn:
            self.active_input = obj
        return super().eventFilter(obj, event)

    def insertar_texto(self, texto):
        if not self.active_input:
            return
        cursor = self.active_input.cursorPosition()
        actual = self.active_input.text()

        

        nuevo = actual[:cursor] + texto + actual[cursor:]
        self.active_input.setText(nuevo)
        self.active_input.setCursorPosition(cursor + len(texto))

    def calcular(self):
        try:
            expr_fx = normalizar_expr(self.fx_input.text())
            expr_gx = normalizar_expr(self.gx_input.text())

            f = crear_funcion_con_lhopital(expr_fx)
            g = crear_funcion_con_lhopital(expr_gx)
            locals_dict = {"pi": sp.pi, "π": sp.pi, "e": sp.E}


            x0 = float(sp.sympify(normalizar_expr(self.x0_input.text()), locals=locals_dict))
            tol = float(sp.sympify(normalizar_expr(self.tol_input.text()), locals=locals_dict))

            x = sp.symbols('x')
            expr_g = sp.sympify(expr_gx, locals=locals_dict)
            g_deriv = sp.diff(expr_g, x)


            

            # --- Chequeamos que converga: g'(semilla)<1  ---
            deriv_val = float(g_deriv.subs(x, x0))
            if abs(deriv_val) >= 1:
                QMessageBox.warning(
                    self,
                    "No converge",
                    f"La función g(x) no es contractiva en x0={x0}.\n"
                    f"|g'(x0)| = {abs(deriv_val):.4f} ≥ 1.\n"
                    "El método de punto fijo/Aitken probablemente no converja.\n"
                    "Intenta redefinir g(x)."
                )
                return  # detener ejecución

            # --- Ejecutamos Aitken recién si pasa el chequeo ---
            raiz, pasos = aitken(g, x0, tol)


            # --- Gráfico ---
            self.ax.clear()
            X = np.linspace(x0 - 2, x0 + 2, 400)
            Yf = [f(val) for val in X]
            Yg = [g(val) for val in X]

            self.ax.plot(X, Yf, "m", label="f(x)")
            self.ax.plot(X, Yg, "b", label="g(x)")
            self.ax.axhline(0, color="black", linewidth=0.8)
            self.ax.axvline(raiz, color="green", linestyle="--", label=f"Raíz ≈ {raiz}")

            self.ax.set_title("Método de aceleración de Aitken")
            self.ax.legend()
            self.ax.grid(True)
            self.canvas.draw()

            # --- Salida ---
            self.output.clear()
            self.output.append(f"Raíz aproximada = {raiz}")
            self.output.append("Iteraciones:")
            for i, x0_i, x1, x2, xa in pasos:
                self.output.append(f"Iteración {i}: x0={x0_i}, x1={x1}, x2={x2}, x acelerado={xa}")

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


# --- Main ---
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AitkenWindow()
    window.show()
    sys.exit(app.exec())
