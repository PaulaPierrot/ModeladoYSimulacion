import sys
import numpy as np
import sympy as sp
import matplotlib
matplotlib.use("QtAgg")
import matplotlib.pyplot as plt

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QMessageBox
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from math_keyboard import MathKeyboard


class SistemaPeriodicoAnalisis(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Análisis de Ecuaciones Diferenciales Periódicas")
        self.setGeometry(100, 100, 1000, 700)
        self.active_input = None

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        # --- Entradas ---
        form_layout = QHBoxLayout()
        layout.addLayout(form_layout)

        self.eq_input = QLineEdit("sin(y)")
        self.var_input = QLineEdit("y")
        self.range_input = QLineEdit("0, 3*pi")

        for entrada in [self.eq_input, self.var_input, self.range_input]:
            entrada.installEventFilter(self)

        form_layout.addWidget(QLabel("dy/dt ="))
        form_layout.addWidget(self.eq_input)
        form_layout.addWidget(QLabel("Variable:"))
        form_layout.addWidget(self.var_input)
        form_layout.addWidget(QLabel("Rango:"))
        form_layout.addWidget(self.range_input)

        # --- Teclado matemático ---
        self.keyboard = MathKeyboard(self.insertar_texto)
        layout.addWidget(self.keyboard)

        # --- Botón ---
        self.calc_btn = QPushButton("Analizar comportamiento periódico")
        self.calc_btn.clicked.connect(self.analizar)
        layout.addWidget(self.calc_btn)

        # --- Gráfico ---
        self.figure, self.ax = plt.subplots(figsize=(8, 5))
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)

        # --- Salida de texto ---
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output)

    def eventFilter(self, obj, event):
        if event.type() == event.Type.FocusIn:
            self.active_input = obj
        return super().eventFilter(obj, event)

    def insertar_texto(self, texto):
        if not self.active_input:
            return
        cursor = self.active_input.cursorPosition()
        actual = self.active_input.text()
        nuevo = actual[:cursor] + texto + actual[cursor:]
        self.active_input.setText(nuevo)
        self.active_input.setCursorPosition(cursor + len(texto))

    def analizar(self):
        try:
            expr_str = self.eq_input.text()
            var = sp.Symbol(self.var_input.text())
            expr = sp.sympify(expr_str)
            f = sp.lambdify(var, expr, "numpy")
            dfdy = sp.diff(expr, var)

            # --- Rango automático ---
            rango_texto = self.range_input.text()
            a_str, b_str = [s.strip() for s in rango_texto.split(",")]
            a = float(sp.N(sp.sympify(a_str)))
            b = float(sp.N(sp.sympify(b_str)))

            X = np.linspace(a, b, 600)
            Y = f(X)

            # --- Calcular puntos de equilibrio ---
            equilibrios = []
            for k in np.linspace(a, b, 40):
                try:
                    sol = sp.nsolve(expr, var, k)
                    solf = float(sol)
                    if a <= solf <= b:
                        if not any(abs(solf - e) < 1e-3 for e in equilibrios):
                            equilibrios.append(solf)
                except Exception:
                    pass

            equilibrios = sorted(equilibrios)
            resultados = []

            self.ax.clear()
            self.ax.plot(X, Y, "b", label=f"f({var}) = {expr_str}")
            self.ax.axhline(0, color="black")

            # --- Dibujar puntos de equilibrio y analizar estabilidad ---
            for eq in equilibrios:
                deriv = float(dfdy.subs(var, eq))
                color = "green" if deriv < 0 else "red"
                estabilidad = "estable (atractor)" if deriv < 0 else "inestable (repulsor)"
                self.ax.scatter(eq, 0, color=color, s=60, zorder=3)
                self.ax.text(eq, 0.08, f"{eq:.2f}\n{estabilidad}",
                             color=color, fontsize=8, ha="center")
                resultados.append((eq, deriv, color))

            # --- Flechitas locales ---
            y_min, y_max = np.min(Y), np.max(Y)
            delta = 0.08 * (b - a)
            for eq, deriv, col in resultados:
                arrow_props = dict(arrowstyle="->", color=col, lw=2, mutation_scale=14)
                if deriv < 0:  # estable → flechas hacia el punto
                    self.ax.annotate("", xy=(eq, 0), xytext=(eq - delta, 0), arrowprops=arrow_props)
                    self.ax.annotate("", xy=(eq, 0), xytext=(eq + delta, 0), arrowprops=arrow_props)
                elif deriv > 0:  # inestable → flechas salen del punto
                    self.ax.annotate("", xy=(eq - delta, 0), xytext=(eq, 0), arrowprops=arrow_props)
                    self.ax.annotate("", xy=(eq + delta, 0), xytext=(eq, 0), arrowprops=arrow_props)

            # --- Flechas globales entre equilibrios ---
            for i in range(len(resultados) - 1):
                y1 = resultados[i][0]
                y2 = resultados[i + 1][0]
                y_mid = (y1 + y2) / 2
                f_mid = f(y_mid)
                if abs(f_mid) < 1e-6:
                    continue
                arrow_color = "blue" if f_mid > 0 else "purple"
                self.ax.arrow(y_mid, 0, np.sign(f_mid) * 0.4, 0,
                              head_width=0.05 * (y_max - y_min),
                              head_length=0.1,
                              fc=arrow_color, ec=arrow_color, lw=1.2, zorder=3)

            self.ax.set_title("Campo de fases periódico")
            self.ax.set_xlabel(f"{var}")
            self.ax.set_ylabel(f"f({var})")
            self.ax.grid(True)
            self.ax.legend()
            self.canvas.draw()

            # --- Salida textual ---
            self.output.clear()
            self.output.append(f"Análisis de f({var}) = {expr_str}\n")
            for eq, deriv, _ in resultados:
                tipo = "estable" if deriv < 0 else "inestable"
                self.output.append(f"Punto de equilibrio: {eq:.5f} → {tipo}")

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


# --- Main ---
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SistemaPeriodicoAnalisis()
    window.show()
    sys.exit(app.exec())
