import sys
import random
import math
import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
from scipy.stats import norm

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QMessageBox
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib

from func_utils import normalizar_expr, crear_funcion_con_lhopital
from math_keyboard import MathKeyboard

matplotlib.use("QtAgg")


def montecarlo_integral(f, a, b, n, semilla, conf):
    random.seed(semilla)
    debajo_x, debajo_y = [], []
    arriba_x, arriba_y = [], []

    # calcular valor máximo de la función en el intervalo
    X = np.linspace(a, b, 500)
    Y = [f(val) for val in X]
    ymax = max(Y)

    # Monte Carlo
    valores_funcion = []
    for _ in range(n):
        x = random.uniform(a, b)
        y = random.uniform(0, ymax)
        fx = f(x)
        valores_funcion.append(fx)

        if y <= fx:
            debajo_x.append(x)
            debajo_y.append(y)
        else:
            arriba_x.append(x)
            arriba_y.append(y)

    # Integral estimada
    promedio = sum(valores_funcion) / len(valores_funcion)
    integral_estimada = (b - a) * promedio

    # Desvío y error estándar
    varianza = sum((v - promedio) ** 2 for v in valores_funcion) / (n - 1)
    desvio = math.sqrt(varianza)
    error_estandar = (b - a) * (desvio / math.sqrt(n))

    # Intervalo de confianza
    z = norm.ppf(1 - (1 - conf) / 2)
    intervalo_inf = integral_estimada - z * error_estandar
    intervalo_sup = integral_estimada + z * error_estandar

    return (integral_estimada, (intervalo_inf, intervalo_sup),
            debajo_x, debajo_y, arriba_x, arriba_y,
            X, Y, desvio, error_estandar)


# --- Ventana principal ---
class MonteCarloWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Integración Numérica - Monte Carlo")
        self.setGeometry(100, 100, 1200, 700)
        self.active_input = None

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        # Entradas
        form_layout = QHBoxLayout()
        layout.addLayout(form_layout)

        self.fx_input = QLineEdit("sin(x)")
        self.a_input = QLineEdit("0")
        self.b_input = QLineEdit("pi")
        self.n_input = QLineEdit("10000")
        self.seed_input = QLineEdit("42")
        self.conf_input = QLineEdit("0.95")

        for entrada in [self.fx_input, self.a_input, self.b_input, self.n_input, self.seed_input, self.conf_input]:
            entrada.installEventFilter(self)

        form_layout.addWidget(QLabel("f(x):"))
        form_layout.addWidget(self.fx_input)
        form_layout.addWidget(QLabel("a:"))
        form_layout.addWidget(self.a_input)
        form_layout.addWidget(QLabel("b:"))
        form_layout.addWidget(self.b_input)
        form_layout.addWidget(QLabel("N:"))
        form_layout.addWidget(self.n_input)
        form_layout.addWidget(QLabel("Semilla:"))
        form_layout.addWidget(self.seed_input)
        form_layout.addWidget(QLabel("Confianza:"))
        form_layout.addWidget(self.conf_input)

        # Teclado matemático
        self.keyboard = MathKeyboard(self.insertar_texto)
        layout.addWidget(self.keyboard)

        # Botón Calcular
        self.calc_btn = QPushButton("Calcular")
        self.calc_btn.clicked.connect(self.calcular)
        layout.addWidget(self.calc_btn)

        # Área de gráfico
        self.figure, self.ax = plt.subplots(figsize=(8, 5))
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)

        # Salida de texto
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output)

    def eventFilter(self, obj, event):
        if event.type() == event.Type.FocusIn:
            self.active_input = obj
        return super().eventFilter(obj, event)

    def insertar_texto(self, texto):
        if not self.active_input:
            return
        cursor = self.active_input.cursorPosition()
        actual = self.active_input.text()
        nuevo = actual[:cursor] + texto + actual[cursor:]
        self.active_input.setText(nuevo)
        self.active_input.setCursorPosition(cursor + len(texto))

    def calcular(self):
        try:
            expr_fx = normalizar_expr(self.fx_input.text())
            f = crear_funcion_con_lhopital(expr_fx)

            locals_dict = {"pi": sp.pi, "π": sp.pi, "e": sp.E}
            a = float(sp.sympify(normalizar_expr(self.a_input.text()), locals=locals_dict))
            b = float(sp.sympify(normalizar_expr(self.b_input.text()), locals=locals_dict))
            n = int(sp.sympify(normalizar_expr(self.n_input.text()), locals=locals_dict))
            semilla = int(sp.sympify(normalizar_expr(self.seed_input.text()), locals=locals_dict))
            conf = float(self.conf_input.text())

            (integral, (ic_inf, ic_sup),
             dx, dy, ax_, ay_,
             X, Y, desvio, error_estandar) = montecarlo_integral(f, a, b, n, semilla, conf)

            # --- Gráfico ---
            self.ax.clear()
            self.ax.plot(X, Y, color="blue", label="f(x)")
            self.ax.scatter(dx, dy, color="green", s=10, alpha=0.5, label="Puntos debajo")
            self.ax.scatter(ax_, ay_, color="red", s=10, alpha=0.5, label="Puntos arriba")
            self.ax.set_title(f"Monte Carlo (N={n}, IC {conf*100}%)")

            texto = (
                f"Integral ≈ {integral}\n"
                f"IC {conf*100}%: [{ic_inf}, {ic_sup}]\n"
                f"N = {n}\n"
                f"Semilla = {semilla}\n"
                f"Desvío estándar = {desvio}\n"
                f"Error estándar = {error_estandar}"
            )
            self.ax.text(
                0.05, 0.95, texto,
                transform=self.ax.transAxes,
                fontsize=10, verticalalignment="top",
                bbox=dict(facecolor="white", alpha=0.8, edgecolor="black")
            )

            self.ax.legend()
            self.ax.grid(True)
            self.canvas.draw()

            # --- Salida de texto con todos los resultados ---
            self.output.clear()
            self.output.append("📊 Resultados del método Monte Carlo:\n")
            self.output.append(f"Integral ≈ {integral}")
            self.output.append(f"IC {conf*100}%: [{ic_inf}, {ic_sup}]")
            self.output.append(f"N = {n}")
            self.output.append(f"Semilla = {semilla}")
            self.output.append(f"Desvío estándar = {desvio}")
            self.output.append(f"Error estándar = {error_estandar}")

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


# --- Main ---
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MonteCarloWindow()
    window.show()
    sys.exit(app.exec())
