from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QMessageBox,
    QGraphicsDropShadowEffect, QComboBox
)
import sys
import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib

matplotlib.use("QtAgg")


def _as_array_like(val, like):
    arr = np.atleast_1d(np.array(val, dtype=float)).ravel()
    if arr.size == 1:
        return np.full_like(np.asarray(like, dtype=float).ravel(), arr.item())
    if np.asarray(like).ndim == 2 and arr.size == np.asarray(like).size:
        return arr.reshape(np.asarray(like).shape)
    return arr


def style_primary_button(btn, *, radius=12, accent="#0ea5e9"):
    btn.setFixedHeight(44)
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    btn.setStyleSheet(f"""
        QPushButton {{
            background: #ffffff;
            color: #0f172a;
            border: 1px solid rgba(0,0,0,0.12);
            border-radius: {radius}px;
            padding: 10px 16px;
            font-weight: 800;
        }}
        QPushButton:hover {{
            background: #f6f8fb;
            border-color: {accent};
        }}
        QPushButton:pressed {{
            background: #eef2f7;
            padding-top: 11px;       
        }}
        QPushButton:disabled {{
            color: rgba(15,23,42,0.35);
            border-color: rgba(0,0,0,0.08);
            background: #fafafa;
        }}
    """)
    shadow = QGraphicsDropShadowEffect(btn)
    shadow.setBlurRadius(22)
    shadow.setOffset(0, 2)
    shadow.setColor(QColor(0, 0, 0, 70))
    btn.setGraphicsEffect(shadow)


class BifurcacionesWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Sistemas Dinámicos y Bifurcaciones")
        self.setGeometry(100, 100, 1600, 1000)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        # --- inputs ---
                # === Primera línea de inputs ===
        top_layout = QHBoxLayout()
        layout.addLayout(top_layout)

        self.bif_combo = QComboBox()
        self.bif_combo.addItems(["Transcrítica", "Silla-Nodo", "Tridente", "Personalizado"])
        self.bif_combo.currentIndexChanged.connect(self.actualizar_input)

        self.eq_input = QLineEdit("r*y - y**2")
        self.var_input = QLineEdit("y")
        self.r_input = QLineEdit("1")
        self.r_neg_input = QLineEdit("-1")
        self.r_pos_input = QLineEdit("1")

        top_layout.addWidget(QLabel("Tipo:"))
        top_layout.addWidget(self.bif_combo)
        top_layout.addWidget(QLabel("dy/dt ="))
        top_layout.addWidget(self.eq_input)
        top_layout.addWidget(QLabel("Variable:"))
        top_layout.addWidget(self.var_input)
        top_layout.addWidget(QLabel("r inicial (campo de pendientes):"))
        top_layout.addWidget(self.r_input)
        top_layout.addWidget(QLabel("r<0:"))
        top_layout.addWidget(self.r_neg_input)
        top_layout.addWidget(QLabel("r>0:"))
        top_layout.addWidget(self.r_pos_input)

        # === Segunda línea de inputs ===
        range_layout = QHBoxLayout()
        layout.addLayout(range_layout)

        self.range_input = QLineEdit("-3,3")
        self.phase_xrange_input = QLineEdit("-3,3")

        range_layout.addWidget(QLabel("Rango de ordenadas f(y):"))
        range_layout.addWidget(self.range_input)
        range_layout.addWidget(QLabel("Rango de abscisas y:"))
        range_layout.addWidget(self.phase_xrange_input)


        # --- botón ---
        self.calc_btn = QPushButton("Analizar sistema")
        style_primary_button(self.calc_btn)
        self.calc_btn.clicked.connect(self.analizar)
        layout.addWidget(self.calc_btn)

        # --- gráficos ---
        self.figure = plt.figure(figsize=(16, 10))
        gs = self.figure.add_gridspec(2, 3, hspace=0.6)
        self.ax1 = self.figure.add_subplot(gs[0, 0])
        self.ax_bif = self.figure.add_subplot(gs[0, 1:])
        self.ax2 = self.figure.add_subplot(gs[1, 0])
        self.ax3 = self.figure.add_subplot(gs[1, 1])
        self.ax4 = self.figure.add_subplot(gs[1, 2])
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)

        # --- salida de texto ---
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output)

    def actualizar_input(self):
        tipo = self.bif_combo.currentText()
        if tipo == "Transcrítica":
            self.eq_input.setText("r*y - y**2")
            self.range_input.setText("-3,3")
            self.phase_xrange_input.setText("-3,3")
        elif tipo == "Silla-Nodo":
            self.eq_input.setText("r + y**2")
            self.range_input.setText("-3,3")
            self.phase_xrange_input.setText("-3,3")
        elif tipo == "Tridente":
            self.eq_input.setText("r*y - y**3")
            self.range_input.setText("-3,3")
            self.phase_xrange_input.setText("-3,3")
        else:
            self.eq_input.setText("r*y*(1 - y)")
            self.range_input.setText("-1,2")
            self.phase_xrange_input.setText("-1,2")

    def analizar(self):
        try:
            var_str = self.var_input.text().strip()
            y_min_lim, y_max_lim = [float(x) for x in self.range_input.text().split(",")]
            x_phase_min, x_phase_max = [float(x) for x in self.phase_xrange_input.text().split(",")]

            r_val = float(self.r_input.text())
            r_neg = float(self.r_neg_input.text())
            r_pos = float(self.r_pos_input.text())

            if not (r_neg < 0 and r_pos > 0):
                QMessageBox.critical(self, "Error", "Debe ingresar r_neg < 0 y r_pos > 0")
                return

            y = sp.Symbol(var_str)
            r = sp.Symbol("r")
            expr_str = self.eq_input.text()
            expr = sp.sympify(expr_str, locals={"y": y, "r": r})
            f = sp.lambdify((y, r), expr, "numpy")

            # limpiar gráficos
            self.ax1.clear(), self.ax2.clear(), self.ax3.clear(), self.ax4.clear(), self.ax_bif.clear()
            resultados = []

            # --- Campo de pendientes (en t-y) ---
            y_vals = np.linspace(y_min_lim, y_max_lim, 25)
            t_vals = np.linspace(-5, 10, 25)
            T, Y = np.meshgrid(t_vals, y_vals)
            DY = f(Y, r_val)
            DT = np.ones_like(DY)
            N = np.sqrt(DT**2 + DY**2)
            self.ax1.quiver(T, Y, DT/N, DY/N, angles="xy", scale_units='xy', scale=1, color='gray')
            self.ax1.set_xlim(np.min(t_vals), np.max(t_vals))
            self.ax1.set_ylim(y_min_lim, y_max_lim)
            self.ax1.set_title(f"Campo de Pendientes (r={r_val})")
            self.ax1.set_xlabel("t")
            self.ax1.set_ylabel(var_str)
            self.ax1.grid(True, linestyle='--', alpha=0.6)

            # --- Helper para diagramas de fases (f(y) vs y) ---
            def graficar_fase(ax, case_r, color, titulo):
                expr_r = expr.subs(r, case_r)
                f_case = sp.lambdify(y, expr_r, "numpy")
                yy = np.linspace(x_phase_min, x_phase_max, 400)
                fy = _as_array_like(f_case(yy), yy)

                ax.plot(yy, fy, color, label=f"r={case_r:.2f}")
                ax.set_xlim(x_phase_min, x_phase_max)
                ax.set_ylim(y_min_lim, y_max_lim)

                dfdy = sp.diff(expr_r, y)
                eq_points = [eq for eq in sp.solve(sp.Eq(expr_r, 0), y) if eq.is_real]

                resultados_locales = []
                for eq in eq_points:
                    stab = float(dfdy.subs(y, eq))
                    color_eq = "green" if stab < 0 else ("red" if stab > 0 else "orange")
                    eq_val = float(eq)
                    ax.scatter(eq_val, 0, color=color_eq, s=68, zorder=4)
                    tipo = "Estable" if stab < 0 else ("Inestable" if stab > 0 else "Neutro")
                    resultados.append(f"Equilibrio en y={eq_val:.3f}, r={case_r:.2f}: {tipo}")
                    resultados_locales.append((eq_val, stab, color_eq))

                # Flechas locales (siempre)
                delta = 0.08 * (x_phase_max - x_phase_min)
                arrow_props = dict(lw=2, mutation_scale=14, head_width=0.0)  # usaremos annotate con arrowstyle

                for eq_val, deriv, col in resultados_locales:
                    left = max(x_phase_min, eq_val - delta)
                    right = min(x_phase_max, eq_val + delta)

                    if deriv < 0:
                        # estable: flechas hacia el punto
                        ax.annotate("", xy=(eq_val, 0), xytext=(left, 0),
                                    arrowprops=dict(arrowstyle="->", color=col, lw=2, mutation_scale=14))
                        ax.annotate("", xy=(eq_val, 0), xytext=(right, 0),
                                    arrowprops=dict(arrowstyle="->", color=col, lw=2, mutation_scale=14))
                    elif deriv > 0:
                        # inestable: flechas salen del punto
                        ax.annotate("", xy=(left, 0), xytext=(eq_val, 0),
                                    arrowprops=dict(arrowstyle="->", color=col, lw=2, mutation_scale=14))
                        ax.annotate("", xy=(right, 0), xytext=(eq_val, 0),
                                    arrowprops=dict(arrowstyle="->", color=col, lw=2, mutation_scale=14))
                    else:
                        # neutro: medir dirección real del flujo a cada lado
                        eps = delta * 0.5
                        y_left = max(x_phase_min, eq_val - eps)
                        y_right = min(x_phase_max, eq_val + eps)
                        f_left = float(f_case(y_left))
                        f_right = float(f_case(y_right))

                        # flecha en el lado izquierdo
                        if f_left > 0:
                            # y crece ⇒ flecha hacia la derecha
                            ax.annotate("", xy=(y_left + eps, 0), xytext=(y_left, 0),
                                        arrowprops=dict(arrowstyle="->", color=col, lw=2, mutation_scale=14))
                        elif f_left < 0:
                            # y decrece ⇒ flecha hacia la izquierda
                            ax.annotate("", xy=(y_left - eps, 0), xytext=(y_left, 0),
                                        arrowprops=dict(arrowstyle="->", color=col, lw=2, mutation_scale=14))

                        # flecha en el lado derecho
                        if f_right > 0:
                            ax.annotate("", xy=(y_right + eps, 0), xytext=(y_right, 0),
                                        arrowprops=dict(arrowstyle="->", color=col, lw=2, mutation_scale=14))
                        elif f_right < 0:
                            ax.annotate("", xy=(y_right - eps, 0), xytext=(y_right, 0),
                                        arrowprops=dict(arrowstyle="->", color=col, lw=2, mutation_scale=14))

                ax.axhline(0, color="k", lw=1)
                ax.set_title(titulo)
                ax.set_xlabel(var_str)
                ax.set_ylabel(f"f({var_str})")
                ax.grid(True, linestyle='--', alpha=0.6)
                ax.legend()

            # Diagramas de fase
            graficar_fase(self.ax2, r_neg, "r", f"Diagrama de fases (r={r_neg})")
            graficar_fase(self.ax3, 0, "g", "Diagrama de fases (r=0)")
            graficar_fase(self.ax4, r_pos, "b", f"Diagrama de fases (r={r_pos})")

            # --- Diagrama de bifurcación ---
            r_vals = np.linspace(-5, 5, 300)
            eq_points = sp.solve(sp.Eq(expr, 0), y)
            dfdy = sp.diff(expr, y)
            for eq in eq_points:
                y_func = sp.lambdify(r, eq, "numpy")
                try:
                    y_vals = np.array(y_func(r_vals), dtype=float)
                    if y_vals.ndim == 0:
                        y_vals = np.full_like(r_vals, float(y_vals))
                except Exception:
                    continue
                dfdy_func = sp.lambdify((y, r), dfdy, "numpy")
                stab_vals = dfdy_func(y_vals, r_vals)
                stable_mask = stab_vals < 0
                unstable_mask = stab_vals > 0
                if np.any(stable_mask):
                    self.ax_bif.plot(r_vals[stable_mask], y_vals[stable_mask], "b-")
                if np.any(unstable_mask):
                    self.ax_bif.plot(r_vals[unstable_mask], y_vals[unstable_mask], "r--")

            self.ax_bif.axhline(0, color="k", lw=1)
            self.ax_bif.axvline(0, color="orange", linestyle=":", lw=2, label="Punto crítico r=0")
            self.ax_bif.set_title("Diagrama de Bifurcación")
            self.ax_bif.set_xlabel("r")
            self.ax_bif.set_ylabel("y*")
            self.ax_bif.grid(True, linestyle='--', alpha=0.6)
            self.ax_bif.legend()
            self.canvas.draw()

            # salida texto
            self.output.clear()
            self.output.append("Ecuación usada: dy/dt = " + str(expr))
            self.output.append("")
            for rtxt in resultados:
                self.output.append(rtxt)

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = BifurcacionesWindow()
    window.show()
    sys.exit(app.exec())

