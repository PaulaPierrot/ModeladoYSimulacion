from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QMessageBox,
    QGraphicsDropShadowEffect, QComboBox, QCheckBox
)
import sys
import numpy as np
import matplotlib
matplotlib.use("QtAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import sympy as sp


# --- estilo del botón ---
def style_primary_button(btn, *, radius=12, accent="#0ea5e9"):
    btn.setFixedHeight(44)
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    btn.setStyleSheet(f"""
        QPushButton {{
            background: #ffffff;
            color: #0f172a;
            border: 1px solid rgba(0,0,0,0.12);
            border-radius: {radius}px;
            padding: 10px 16px;
            font-weight: 800;
        }}
        QPushButton:hover {{
            background: #f6f8fb;
            border-color: {accent};
        }}
        QPushButton:pressed {{
            background: #eef2f7;
            padding-top: 11px;       
        }}
    """)
    shadow = QGraphicsDropShadowEffect(btn)
    shadow.setBlurRadius(22)
    shadow.setOffset(0, 2)
    shadow.setColor(QColor(0, 0, 0, 70))
    btn.setGraphicsEffect(shadow)


class FaseLineal2DWindow(QMainWindow):
    def mostrar_ayuda(self):
        texto = (
            "<b>Parte lineal (Ax)</b>: ecuaciones lineales del sistema (por ejemplo ẋ = -x, ẏ = -2y).<br><br>"
            "<b>Modo</b>: determina si el sistema es homogéneo (b = 0) o no homogéneo, con un término "
            "constante b o dependiente del tiempo B(t).<br><br>"
            "<b>B (componentes bx, by)</b>: vector de entrada o perturbación del sistema; puede ser constante o función de t.<br><br>"
            "<b>t(campo)</b>: instante temporal en el que se evalúa el campo vectorial (solo relevante si B depende de t).<br><br>"
            "<b>t₀</b>: tiempo inicial para integrar trayectorias (RK4).<br><br>"
            "<b>t máx</b>: tiempo total de integración, controla la longitud de las trayectorias.<br><br>"
            "<b>#trayec</b>: cantidad de trayectorias a dibujar desde distintas condiciones iniciales.<br><br>"
            "<b>Rango x / Rango y</b>: límites del plano de fase que se graficará.<br><br>"
            "<b>Preset Ax</b>: permite elegir configuraciones típicas (nodo, foco, silla, etc.) para llenar automáticamente las ecuaciones lineales.<br><br>"
            "<b>Dibujar trayectorias (RK4)</b>: si está activado, integra numéricamente y muestra las trayectorias en el campo de fases."
        )
        QMessageBox.information(self, "Ayuda de Inputs", texto)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Diagrama de Fases - Sistemas Lineales 2D (Homogéneos y No Homogéneos)")
        self.setGeometry(100, 100, 1280, 860)

        self.x, self.y, self.t = sp.symbols("x y t", real=True)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        # --- fila 1: parte lineal Ax ---
        fila1 = QHBoxLayout()
        layout.addLayout(fila1)
        fila1.addWidget(QLabel("Parte lineal (Ax):"))
        self.xdot_input = QLineEdit("-x")     # podés cambiar
        self.ydot_input = QLineEdit("-2*y")   # podés cambiar
        fila1.addWidget(QLabel("ẋ_lin ="))
        fila1.addWidget(self.xdot_input)
        fila1.addWidget(QLabel("ẏ_lin ="))
        fila1.addWidget(self.ydot_input)

        # --- fila 2: modo, B(...), t de campo, rangos, t0, tmax, ntraj ---
        fila2 = QHBoxLayout()
        layout.addLayout(fila2)

        self.modo_combo = QComboBox()
        self.modo_combo.addItems([
            "Homogéneo (b = 0)",
            "No homogéneo: b constante",
            "No homogéneo: B(t)",
        #    "Afín general: B(t,x,y)"
        ])

        self.bx_input = QLineEdit("cos(t)")   # por defecto cos(t) para ver el caso típico
        self.by_input = QLineEdit("0")

        self.tfield_input = QLineEdit("0")  # tiempo para evaluar el campo en streamplot
        self.t0_input = QLineEdit("0")      # tiempo inicial para integrar trayectorias
        self.tmax_input = QLineEdit("10")
        self.ntraj_input = QLineEdit("14")

        self.range_x_input = QLineEdit("-5,5")
        self.range_y_input = QLineEdit("-5,5")

        fila2.addWidget(QLabel("Modo:"))
        fila2.addWidget(self.modo_combo)
        fila2.addWidget(QLabel("B (componentes):"))
        fila2.addWidget(QLabel("bx ="))
        fila2.addWidget(self.bx_input)
        fila2.addWidget(QLabel("by ="))
        fila2.addWidget(self.by_input)
        fila2.addWidget(QLabel("t(campo)="))
        fila2.addWidget(self.tfield_input)
        fila2.addWidget(QLabel("t0="))
        fila2.addWidget(self.t0_input)
        fila2.addWidget(QLabel("t máx="))
        fila2.addWidget(self.tmax_input)
        fila2.addWidget(QLabel("#trayec="))
        fila2.addWidget(self.ntraj_input)

        # --- fila 3: rangos + presets lineales comunes ---
        fila3 = QHBoxLayout()
        layout.addLayout(fila3)
        fila3.addWidget(QLabel("Rango x:"))
        fila3.addWidget(self.range_x_input)
        fila3.addWidget(QLabel("Rango y:"))
        fila3.addWidget(self.range_y_input)

        self.preset_combo = QComboBox()
        self.preset_combo.addItems([
            "Personalizado",
            "Nodo estable (diag. negativa)",
            "Nodo inestable (diag. positiva)",
            "Silla",
            "Foco estable",
            "Foco inestable",
            "Centro (rotación pura)",
            "Degenerado (Jordan λ=0)"
        ])
        self.preset_combo.currentIndexChanged.connect(self._aplicar_preset)
        fila3.addWidget(QLabel("Preset Ax:"))
        fila3.addWidget(self.preset_combo)

        # --- fila 4: opciones de dibujo ---
        fila4 = QHBoxLayout()
        layout.addLayout(fila4)
        self.chk_trayectorias = QCheckBox("Dibujar trayectorias (RK4)")
        self.chk_trayectorias.setChecked(True)
        fila4.addWidget(self.chk_trayectorias)
        
        # --- boton de ayuda porque quedó medio confuso el input---
        self.help_btn = QPushButton("¿Qué significa cada input?")
        style_primary_button(self.help_btn)
        self.help_btn.clicked.connect(self.mostrar_ayuda)
        layout.addWidget(self.help_btn)


        # --- botón ---
        self.calc_btn = QPushButton("Analizar sistema")
        style_primary_button(self.calc_btn)
        self.calc_btn.clicked.connect(self.analizar)
        layout.addWidget(self.calc_btn)

        # --- gráfico ---
        self.figure, self.ax = plt.subplots(1, 1, figsize=(10.6, 6.6))
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)

        # --- salida texto ---
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output)

    # ================== helpers ==================
    def _aplicar_preset(self):
        presets = {
            1: ("-x", "-2*y"),
            2: ("x", "2*y"),
            3: ("x", "-y"),
            4: ("-0.5*x - 2*y", "2*x - 0.5*y"),
            5: ("0.5*x - 2*y", "2*x + 0.5*y"),
            6: ("-y", "x"),
            7: ("x + y", "-x - y"),
        }
        i = self.preset_combo.currentIndex()
        if i in presets:
            xdot, ydot = presets[i]
            self.xdot_input.setText(xdot)
            self.ydot_input.setText(ydot)

    def _lambdas_total(self, fx_total, gy_total):
        return sp.lambdify((self.x, self.y, self.t), fx_total, "numpy"), sp.lambdify((self.x, self.y, self.t), gy_total, "numpy")

    def _clasificar(self, A):
        tau = float(A.trace())
        det = float(A.det())
        disc = tau * tau - 4 * det
        if det < 0:
            tipo = "Silla (saddle)"
        elif det > 0 and disc > 0:
            tipo = "Nodo estable (τ<0)" if tau < 0 else "Nodo inestable (τ>0)"
        elif det > 0 and disc < 0:
            tipo = "Foco estable (τ<0)" if tau < 0 else ("Foco inestable (τ>0)" if tau > 0 else "Centro")
        elif det == 0 and tau == 0:
            tipo = "Degenerado nulo"
        else:
            tipo = "Nodo degenerado (λ doble)"
        return tipo, tau, det, disc

    def _rk4(self, f, g, x0, y0, t0, t1, nsteps):
        xs = [x0]
        ys = [y0]
        ts = [t0]
        h = (t1 - t0) / nsteps
        x = x0
        y = y0
        t = t0
        for _ in range(nsteps):
            k1x = f(x, y, t)
            k1y = g(x, y, t)
            k2x = f(x + 0.5*h*k1x, y + 0.5*h*k1y, t + 0.5*h)
            k2y = g(x + 0.5*h*k1x, y + 0.5*h*k1y, t + 0.5*h)
            k3x = f(x + 0.5*h*k2x, y + 0.5*h*k2y, t + 0.5*h)
            k3y = g(x + 0.5*h*k2x, y + 0.5*h*k2y, t + 0.5*h)
            k4x = f(x + h*k3x, y + h*k3y, t + h)
            k4y = g(x + h*k3x, y + h*k3y, t + h)
            x = x + (h/6.0)*(k1x + 2*k2x + 2*k3x + k4x)
            y = y + (h/6.0)*(k1y + 2*k2y + 2*k3y + k4y)
            t = t + h
            xs.append(x)
            ys.append(y)
            ts.append(t)
        return np.array(xs), np.array(ys), np.array(ts)

    def _grid_initial_conditions(self, x_min, x_max, y_min, y_max, n):
        rngx = np.linspace(x_min, x_max, int(np.sqrt(n))+2)[1:-1]
        rngy = np.linspace(y_min, y_max, int(np.sqrt(n))+2)[1:-1]
        pts = []
        for xi in rngx:
            for yi in rngy:
                pts.append((xi, yi))
                if len(pts) >= n:
                    return pts
        return pts

    # ================== análisis ==================
    def analizar(self):
        try:
            # --- leer entradas ---
            fx_lin = sp.sympify(self.xdot_input.text(), locals={"x": self.x, "y": self.y})
            gy_lin = sp.sympify(self.ydot_input.text(), locals={"x": self.x, "y": self.y})
            modo = self.modo_combo.currentIndex()

            # B según modo
            local_syms = {"x": self.x, "y": self.y, "t": self.t}
            bx_expr = sp.sympify(self.bx_input.text(), locals=local_syms)
            by_expr = sp.sympify(self.by_input.text(), locals=local_syms)

            # Rango y tiempo
            x_min, x_max = [float(v) for v in self.range_x_input.text().split(",")]
            y_min, y_max = [float(v) for v in self.range_y_input.text().split(",")]
            t_field = float(self.tfield_input.text())
            t0 = float(self.t0_input.text())
            tmax = float(self.tmax_input.text())
            ntraj = max(1, int(float(self.ntraj_input.text())))

            # Matriz A solo de la parte lineal
            A = sp.Matrix([
                [sp.diff(fx_lin, self.x), sp.diff(fx_lin, self.y)],
                [sp.diff(gy_lin, self.x), sp.diff(gy_lin, self.y)]
            ])
            A_simpl = sp.simplify(A)

            # total RHS
            if modo == 0:
                fx_total = fx_lin
                gy_total = gy_lin
            elif modo == 1:
                fx_total = fx_lin + bx_expr
                gy_total = gy_lin + by_expr
            elif modo == 2:
                fx_total = fx_lin + bx_expr
                gy_total = gy_lin + by_expr
            else:
                fx_total = fx_lin + bx_expr
                gy_total = gy_lin + by_expr

            # --- clasificación por A ---
            eig_data = A_simpl.eigenvects()
            tipo, tau, det, disc = self._clasificar(A_simpl)

            # --- funciones numéricas ---
            fnum, gnum = self._lambdas_total(fx_total, gy_total)
            fnum_field = lambda X, Y: fnum(X, Y, t_field)
            gnum_field = lambda X, Y: gnum(X, Y, t_field)
            fnum_traj = lambda x, y, tt: float(fnum(x, y, tt))
            gnum_traj = lambda x, y, tt: float(gnum(x, y, tt))

            # --- gráfico: campo vectorial en t = t_field ---
            self.ax.clear()
            Xg, Yg = np.meshgrid(np.linspace(x_min, x_max, 25), np.linspace(y_min, y_max, 25))
            U = fnum_field(Xg, Yg)
            V = gnum_field(Xg, Yg)
            self.ax.streamplot(Xg, Yg, U, V, density=1.2, linewidth=1)
            self.ax.set_xlim(x_min, x_max)
            self.ax.set_ylim(y_min, y_max)
            self.ax.grid(True, linestyle='--', alpha=0.5)
            self.ax.set_title(f"Diagrama de Fases (campo en t = {t_field:g})")
            self.ax.set_xlabel("x")
            self.ax.set_ylabel("y")

            # --- equilibria / puntos particular(es) ---
            equilibrio_txt = ""
            equilibria_pts = []

            if modo == 0:
                # Homogéneo: equilibrio en (0,0)
                equilibria_pts.append((0.0, 0.0))
                equilibrio_txt = "Equilibrio: (0, 0)"
            elif modo == 1:
                # b constante: AX + b = 0
                b_vec = sp.Matrix([bx_expr, by_expr])
                if A_simpl.det() != 0:
                    Xp = -A_simpl.inv() * b_vec
                    Xp_s = sp.simplify(Xp)
                    try:
                        xe, ye = float(Xp_s[0]), float(Xp_s[1])
                        equilibria_pts.append((xe, ye))
                        equilibrio_txt = f"Equilibrio (constante): ({xe:.6g}, {ye:.6g})"
                    except Exception:
                        equilibrio_txt = f"Equilibrio simbólico: Xp = {Xp_s}"
                else:
                    sol = sp.linsolve((A_simpl, -b_vec))
                    if sol:
                        sol_tuple = list(sol)[0]
                        try:
                            xe, ye = [float(sp.N(v)) for v in sol_tuple]
                            equilibria_pts.append((xe, ye))
                            equilibrio_txt = f"Equilibrio (constante): ({xe:.6g}, {ye:.6g})"
                        except Exception:
                            equilibrio_txt = f"Conjunto de equilibrios: Xp ∈ {sol}"
                    else:
                        equilibrio_txt = "No se pudo determinar un equilibrio constante (A singular y sin solución)."
            elif modo == 2:
                # B(t): no hay punto fijo; Xp(t) = -A^{-1}B(t) si A es invertible
                b_t = sp.Matrix([bx_expr, by_expr])
                if A_simpl.det() != 0:
                    Xp_t = -A_simpl.inv() * b_t
                    equilibrio_txt = f"No hay equilibrio fijo; particular dependiente de t: Xp(t) = {sp.simplify(Xp_t)}"
                else:
                    equilibrio_txt = "A es singular; no hay Xp(t) global por inversión. Variación de parámetros aplica."
            else:
                # B(t,x,y): resolver Ax + B(x,y,t)=0 en t=t_field (equilibrio cuasiestático)
                b_gen = sp.Matrix([bx_expr.subs(self.t, t_field), by_expr.subs(self.t, t_field)])
                x_sym, y_sym = sp.symbols("x_eq y_eq", real=True)
                eq1 = sp.simplify(fx_lin.subs({self.x: x_sym, self.y: y_sym}) + b_gen[0])
                eq2 = sp.simplify(gy_lin.subs({self.x: x_sym, self.y: y_sym}) + b_gen[1])
                try:
                    sol = sp.nsolve([eq1, eq2], [x_sym, y_sym], (0.0, 0.0))
                    xe, ye = float(sol[0]), float(sol[1])
                    equilibria_pts.append((xe, ye))
                    equilibrio_txt = f"Punto de equilibrio para t={t_field:g}: ({xe:.6g}, {ye:.6g})"
                except Exception:
                    equilibrio_txt = "No se halló equilibrio (t fijo) con nsolve desde (0,0)."

            for (xe, ye) in equilibria_pts:
                self.ax.plot(xe, ye, "ro", ms=6, label="Equilibrio")
            if equilibria_pts:
                self.ax.legend()

            # --- trayectorias con RK4 ---
            if self.chk_trayectorias.isChecked():
                inits = self._grid_initial_conditions(x_min, x_max, y_min, y_max, ntraj)
                steps = max(200, int(50 * tmax))
                for (x0, y0) in inits:
                    xs, ys, _ = self._rk4(fnum_traj, gnum_traj, x0, y0, t0, t0 + tmax, steps)
                    self.ax.plot(xs, ys, linewidth=1)

            self.canvas.draw()

            # --- salida analítica / reporte ---
            self.output.clear()
            self.output.append("Sistema (se interpreta como Ẋ = A·X + B):")
            self.output.append(f"  ẋ_lin = {sp.simplify(fx_lin)}")
            self.output.append(f"  ẏ_lin = {sp.simplify(gy_lin)}")
            self.output.append(f"  bx = {sp.simplify(bx_expr)}")
            self.output.append(f"  by = {sp.simplify(by_expr)}\n")

            self.output.append("Matriz A (derivada de la parte lineal Ax):")
            self.output.append(str(sp.simplify(A_simpl)))
            self.output.append("")

            self.output.append(f"τ = {tau:.6g}, det = {det:.6g}, D = {disc:.6g}")
            self.output.append(f"Clasificación (por A): {tipo}\n")

            self.output.append("Autovalores y autovectores de A:")
            for ev in eig_data:
                self.output.append(f"  λ = {sp.N(ev[0])}, mult. {ev[1]}")
                for j, v in enumerate(ev[2], start=1):
                    self.output.append(f"     v{j} = {sp.N(sp.Matrix(v))}")
            self.output.append("")

            # --- soluciones analíticas según modo ---
            c1, c2 = sp.symbols("c1 c2", real=True)
            t = self.t

            if modo == 0 or modo == 1:
                # Sol homogénea con eigenestructura
                try:
                    eig_data_simple = A_simpl.eigenvects()
                    if len(eig_data_simple) == 1 and eig_data_simple[0][1] == 2:
                        lam, _, vecs = eig_data_simple[0]
                        if len(vecs) == 2:
                            Xh_t = sp.exp(lam * t) * (c1 * sp.Matrix(vecs[0]) + c2 * sp.Matrix(vecs[1]))
                        else:
                            v = sp.Matrix(vecs[0])
                            M = A_simpl - lam * sp.eye(2)
                            sol = sp.linsolve((M, v))
                            wv = list(sol)[0] if sol else (0, 0)
                            w = sp.Matrix(wv)
                            Xh_t = sp.exp(lam * t) * (c1 * v + c2 * (t * v + w))
                    elif any(sp.im(ev[0]) != 0 for ev in eig_data_simple):
                        lam = eig_data_simple[0][0]
                        v = eig_data_simple[0][2][0]
                        alpha, beta = sp.re(lam), sp.im(lam)
                        a, b = sp.re(v), sp.im(v)
                        Xh_t = sp.exp(alpha * t) * (
                            c1 * (a * sp.cos(beta * t) - b * sp.sin(beta * t)) +
                            c2 * (a * sp.sin(beta * t) + b * sp.cos(beta * t))
                        )
                    else:
                        (lam1, _, v1), (lam2, _, v2) = eig_data_simple[0], eig_data_simple[1]
                        Xh_t = c1 * sp.exp(lam1 * t) * sp.Matrix(v1[0]) + c2 * sp.exp(lam2 * t) * sp.Matrix(v2[0])

                    if modo == 0:
                        self.output.append("Solución general (homogénea):")
                        self.output.append(f"  X(t) = {sp.simplify(Xh_t)}\n")
                    else:
                        # b constante: X(t) = Xp + Xh(t) con Xp = -A^{-1}b
                        b_vec = sp.Matrix([bx_expr, by_expr])
                        if A_simpl.det() != 0:
                            Xp = -A_simpl.inv() * b_vec
                            self.output.append("Solución general (no homogéneo con b constante):")
                            self.output.append(f"  Xp = {sp.simplify(Xp)}")
                            self.output.append(f"  X(t) = Xp + {sp.simplify(Xh_t)}\n")
                            # Forma explícita (sumando homogénea y particular)
                            x_t = sp.simplify(Xp[0] + Xh_t[0])
                            y_t = sp.simplify(Xp[1] + Xh_t[1])
                            self.output.append("Forma explícita (sumando homogénea y particular):")
                            self.output.append(f"  x(t) = {x_t}")
                            self.output.append(f"  y(t) = {y_t}\n")
                        else:
                            self.output.append("A es singular: no se puede escribir Xp = -A^{-1}b globalmente.\n")

                except Exception as e:
                    self.output.append(f"No se pudo construir solución analítica homogénea: {e}\n")

            elif modo == 2:
                # B(t): variación de parámetros / Convolución
                try:
                    B_t = sp.Matrix([bx_expr, by_expr])
                    Aexp = sp.exp(A_simpl * t)
                    tau = sp.symbols("tau", real=True)
                    integral = sp.integrate(sp.exp(A_simpl * (t - tau)) * B_t.subs(t, tau), (tau, 0, t))
                    self.output.append("Solución general (no homogéneo con B(t)):")
                    self.output.append("  X(t) = e^(A·t)·X(0) + ∫_0^t e^(A·(t-τ))·B(τ) dτ")
                    self.output.append(f"  e^(A·t) = {sp.simplify(Aexp)}")
                    self.output.append(f"  ∫ = {sp.simplify(integral)}\n")
                except Exception as e:
                    B_t = sp.Matrix([bx_expr, by_expr])
                    tau = sp.symbols("tau", real=True)
                    integral = sp.Integral(sp.exp(A_simpl * (t - tau)) * B_t.subs(t, tau), (tau, 0, t))
                    Aexp = sp.exp(A_simpl * t)
                    self.output.append("Solución general (no homogéneo con B(t)) (forma simbólica no evaluada):")
                    self.output.append("  X(t) = e^(A·t)·X(0) + ∫_0^t e^(A·(t-τ))·B(τ) dτ")
                    self.output.append(f"  e^(A·t) = {Aexp}")
                    self.output.append(f"  ∫ = {integral}\n")
                    self.output.append(f"Aviso: la integral no pudo evaluarse automáticamente ({e}).\n")

                # ---- Forma explícita adicional cuando el sistema se desacopla (A diagonal) ----
                # x' = a11 x + bx(t),  y' = a22 y + by(t)
                try:
                    a11 = sp.simplify(A_simpl[0, 0])
                    a22 = sp.simplify(A_simpl[1, 1])
                    off1 = sp.simplify(A_simpl[0, 1])
                    off2 = sp.simplify(A_simpl[1, 0])

                    bx_free = set(sp.simplify(bx_expr).free_symbols) - {self.x, self.y}
                    by_free = set(sp.simplify(by_expr).free_symbols) - {self.x, self.y}

                    is_diagonal = (off1 == 0) and (off2 == 0)
                    bx_depends_only_t = bx_free.issubset({self.t})
                    by_depends_only_t = by_free.issubset({self.t})

                    if is_diagonal and bx_depends_only_t and by_depends_only_t:
                        c1_sym, c2_sym = sp.symbols("c1 c2", real=True)
                        tau = sp.symbols("tau", real=True)
                        # x(t)
                        Ix = sp.integrate(sp.exp(-a11 * tau) * sp.simplify(bx_expr).subs(self.t, tau), (tau, 0, t))
                        x_explicit = c1_sym * sp.exp(a11 * t) + sp.exp(a11 * t) * Ix
                        # y(t)
                        Iy = sp.integrate(sp.exp(-a22 * tau) * sp.simplify(by_expr).subs(self.t, tau), (tau, 0, t))
                        y_explicit = c2_sym * sp.exp(a22 * t) + sp.exp(a22 * t) * Iy

                        self.output.append("Forma explícita (sumando homogénea y particular, sistema desacoplado):")
                        self.output.append(f"  x(t) = {sp.simplify(x_explicit)}")
                        self.output.append(f"  y(t) = {sp.simplify(y_explicit)}\n")
                except Exception:
                    pass  # si no se puede, no forzamos

            else:
                # B(t,x,y): no hay forma cerrada general
                self.output.append("Caso afín general B(t,x,y):")
                self.output.append("  No existe en general una forma cerrada para X(t). Se muestran campo y trayectorias numéricas (RK4).\n")

            # reporte de equilibrio si lo hubo
            if equilibrio_txt:
                self.output.append(equilibrio_txt + "\n")

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FaseLineal2DWindow()
    window.show()
    sys.exit(app.exec())
