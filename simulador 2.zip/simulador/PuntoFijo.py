import sys
import numpy as np
import matplotlib.pyplot as plt
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QMessageBox, QGridLayout
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib
import sympy as sp
from math_keyboard import MathKeyboard
from func_utils import normalizar_expr, crear_funcion_con_lhopital
matplotlib.use("QtAgg")


       

# --- Método de Punto Fijo ---
def punto_fijo(g, p0, tol, max_iter=100):
    x = g(p0)
    pasos = [(0, p0, x)]
    error = abs(x - p0)
    i = 0

    while error > tol and i < max_iter:
        x1 = g(x)
        i += 1
        error = abs(x1 - x)
        pasos.append((i, x, x1))
        x = x1

    if i == max_iter:
        raise ValueError("No converge en las iteraciones máximas")
    return x, pasos


# --- Ventana principal ---
class PuntoFijoWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Punto Fijo - Método iterativo")
        self.setGeometry(100, 100, 1000, 700)
        self.active_input = None  # input actual para el teclado

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        # --- Entradas ---
        form_layout = QHBoxLayout()
        layout.addLayout(form_layout)

        self.g_input = QLineEdit("(x+3-2*x^2)^(1/4)")
        self.f_input = QLineEdit("x^4 + 2*x^2 - x - 3")  # opcional, el usuario puede cambiarlo
        self.p0_input = QLineEdit("1")
        self.tol_input = QLineEdit("0.0001")

        for entrada in [self.g_input, self.f_input, self.p0_input, self.tol_input]:
            entrada.installEventFilter(self)

        form_layout.addWidget(QLabel("g(x):"))
        form_layout.addWidget(self.g_input)
        form_layout.addWidget(QLabel("f(x):"))
        form_layout.addWidget(self.f_input)
        form_layout.addWidget(QLabel("x₀:"))
        form_layout.addWidget(self.p0_input)
        form_layout.addWidget(QLabel("Tolerancia:"))
        form_layout.addWidget(self.tol_input)

        # --- Teclado matemático ---
        self.keyboard = MathKeyboard(self.insertar_texto)
        layout.addWidget(self.keyboard)


        # --- Botón Calcular ---
        self.calc_btn = QPushButton("Calcular raíz (Punto Fijo)")
        self.calc_btn.clicked.connect(self.calcular)
        layout.addWidget(self.calc_btn)

        # --- Área de gráfico ---
        self.figure, self.ax = plt.subplots(figsize=(8, 5))
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)

        # --- Salida de texto ---
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output)

    def eventFilter(self, obj, event):
        """Detecta cuál input tiene el foco."""
        if event.type() == event.Type.FocusIn:
            self.active_input = obj
        return super().eventFilter(obj, event)

    def insertar_texto(self, texto):
        """Inserta texto en el input activo."""
        if not self.active_input:
            return
        cursor = self.active_input.cursorPosition()
        actual = self.active_input.text()


        nuevo = actual[:cursor] + texto + actual[cursor:]
        self.active_input.setText(nuevo)
        self.active_input.setCursorPosition(cursor + len(texto))

    def calcular(self):
        try:
            g_str = self.g_input.text()
            f_str = self.f_input.text()

            g = crear_funcion_con_lhopital(g_str)
            f = crear_funcion_con_lhopital(f_str)
            p0 = float(sp.sympify(normalizar_expr(self.p0_input.text()), locals={"pi": sp.pi, "E": sp.E}))
            tol = float(sp.sympify(normalizar_expr(self.tol_input.text()), locals={"pi": sp.pi, "E": sp.E}))

            raiz, pasos = punto_fijo(g, p0, tol)

            # --- Gráfico ---
            self.ax.clear()
            X = np.linspace(p0-2, p0+2, 400)
            Yg = [g(val) for val in X]
            Yf = [f(val) for val in X]

            self.ax.plot(X, Yg, "b", label="g(x)")
            self.ax.plot(X, X, "r--", label="y=x")
            self.ax.plot(X, Yf, "m", label="f(x)")
            self.ax.axhline(0, color="black", linewidth=0.8)
            self.ax.axvline(raiz, color="green", linestyle="--", label=f"Raíz ≈ {raiz}")

            self.ax.set_title("Método de Punto Fijo")
            self.ax.legend()
            self.ax.grid(True)
            self.canvas.draw()

            # --- Salida ---
            self.output.clear()
            self.output.append(f"Raíz aproximada = {raiz}")
            self.output.append("Iteraciones:")
            for i, xi, xnext in pasos:
                self.output.append(f"Iter {i}: x={xi}, g(x)={xnext}")

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


# --- Main ---
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PuntoFijoWindow()
    window.show()
    sys.exit(app.exec())
