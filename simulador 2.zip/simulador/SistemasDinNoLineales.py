from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QMessageBox,
    QGraphicsDropShadowEffect
)
import sys
import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib

matplotlib.use("QtAgg")

# --- constantes ---
TMAX = 20
DT = 0.02

# --- estilo del botón ---
def style_primary_button(btn, *, radius=12, accent="#0ea5e9"):
    btn.setFixedHeight(44)
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    btn.setStyleSheet(f"""
        QPushButton {{
            background: #ffffff;
            color: #0f172a;
            border: 1px solid rgba(0,0,0,0.12);
            border-radius: {radius}px;
            padding: 10px 16px;
            font-weight: 800;
        }}
        QPushButton:hover {{
            background: #f6f8fb;
            border-color: {accent};
        }}
        QPushButton:pressed {{
            background: #eef2f7;
            padding-top: 11px;
        }}
    """)
    shadow = QGraphicsDropShadowEffect(btn)
    shadow.setBlurRadius(22)
    shadow.setOffset(0, 2)
    shadow.setColor(QColor(0, 0, 0, 70))
    btn.setGraphicsEffect(shadow)


class FaseNoLineal2DWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Diagrama de Fases - Sistemas No Lineales 2D")
        self.setGeometry(100, 100, 1200, 860)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        # --- inputs ---
        form_layout = QHBoxLayout()
        layout.addLayout(form_layout)

        self.xdot_input = QLineEdit("y")
        self.ydot_input = QLineEdit("x* (3-x)")
        self.range_x_input = QLineEdit("-5,5")
        self.range_y_input = QLineEdit("-5,5")
        self.ntraj_input = QLineEdit("15")

        form_layout.addWidget(QLabel("ẋ ="))
        form_layout.addWidget(self.xdot_input)
        form_layout.addWidget(QLabel("ẏ ="))
        form_layout.addWidget(self.ydot_input)
        form_layout.addWidget(QLabel("Rango x:"))
        form_layout.addWidget(self.range_x_input)
        form_layout.addWidget(QLabel("Rango y:"))
        form_layout.addWidget(self.range_y_input)
        form_layout.addWidget(QLabel("#trayec:"))
        form_layout.addWidget(self.ntraj_input)

        # --- botón ---
        self.calc_btn = QPushButton("Analizar sistema")
        style_primary_button(self.calc_btn)
        self.calc_btn.clicked.connect(self.analizar)
        layout.addWidget(self.calc_btn)

        # --- gráfico ---
        self.figure, self.ax = plt.subplots(1, 1, figsize=(10.5, 6.6))
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)

        # --- salida texto ---
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output)

    # ================== clasificación ==================
    def _clasificar_equilibrio(self, J):
        J = np.array(J, dtype=float)
        vals = [complex(v) for v in np.linalg.eigvals(J)]
        tr = float(np.trace(J))
        det = float(np.linalg.det(J))
        disc = tr * tr - 4 * det

        if det < 0:
            return "Silla", tr, det, disc, vals

        if det > 0 and disc > 0:
            tipo = "Nodo estable" if tr < 0 else "Nodo inestable"
            return tipo, tr, det, disc, vals

        if det > 0 and disc < 0:
            if tr < 0:
                return "Foco estable", tr, det, disc, vals
            elif tr > 0:
                return "Foco inestable", tr, det, disc, vals
            else:
                return "Centro (lineal)", tr, det, disc, vals

        if det > 0 and abs(disc) < 1e-12:
            lam = tr / 2.0
            rank = np.linalg.matrix_rank(J - lam * np.eye(2))
            if rank == 0:
                tipo = "Nodo estrella estable" if tr < 0 else "Nodo estrella inestable"
            else:
                tipo = "Nodo degenerado estable" if tr < 0 else "Nodo degenerado inestable"
            return tipo, tr, det, disc, vals

        if det == 0 and tr == 0:
            return "Degenerado", tr, det, disc, vals

        return "Indeterminado", tr, det, disc, vals

    # ================== numéricos ==================
    def _rk4(self, f, x0, y0, tmax, dt):
        n = int(max(1, tmax / dt))
        xs, ys = np.empty(n + 1), np.empty(n + 1)
        xs[0], ys[0] = x0, y0
        for k in range(n):
            k1 = np.asarray(f(xs[k], ys[k])).reshape(2)
            k2 = np.asarray(f(xs[k] + 0.5 * dt * k1[0], ys[k] + 0.5 * dt * k1[1])).reshape(2)
            k3 = np.asarray(f(xs[k] + 0.5 * dt * k2[0], ys[k] + 0.5 * dt * k2[1])).reshape(2)
            k4 = np.asarray(f(xs[k] + dt * k3[0], ys[k] + dt * k3[1])).reshape(2)
            inc = (k1 + 2 * k2 + 2 * k3 + k4) * (dt / 6)
            xs[k + 1], ys[k + 1] = xs[k] + inc[0], ys[k] + inc[1]
        return xs, ys

    # ================== análisis ==================
    def analizar(self):
        try:
            self.x, self.y = sp.symbols("x y")
            fx = sp.sympify(self.xdot_input.text(), locals={"x": self.x, "y": self.y})
            gy = sp.sympify(self.ydot_input.text(), locals={"x": self.x, "y": self.y})

            x_min, x_max = [float(v) for v in self.range_x_input.text().split(",")]
            y_min, y_max = [float(v) for v in self.range_y_input.text().split(",")]
            ntraj = int(self.ntraj_input.text())

            fnum = sp.lambdify((self.x, self.y), fx, "numpy")
            gnum = sp.lambdify((self.x, self.y), gy, "numpy")
            fvec = sp.lambdify((self.x, self.y), sp.Matrix([fx, gy]), "numpy")

            self.ax.clear()
            Xg, Yg = np.meshgrid(np.linspace(x_min, x_max, 30), np.linspace(y_min, y_max, 30))
            U, V = fnum(Xg, Yg), gnum(Xg, Yg)
            self.ax.streamplot(Xg, Yg, U, V, density=1.2, linewidth=1)

            # --- nulclinas siempre ---
            try:
                self.ax.contour(Xg, Yg, U, levels=[0], colors="blue", linestyles="--")
                self.ax.contour(Xg, Yg, V, levels=[0], colors="red", linestyles=":")
            except Exception:
                pass

            # --- Jacobiano y puntos de equilibrio ---
            J = sp.Matrix([[sp.diff(fx, self.x), sp.diff(fx, self.y)],
                           [sp.diff(gy, self.x), sp.diff(gy, self.y)]])
            sols = sp.solve((sp.Eq(fx, 0), sp.Eq(gy, 0)), (self.x, self.y), dict=True)

            self.output.clear()
            self.output.append("Sistema no lineal:")
            self.output.append(f"  ẋ = {fx}")
            self.output.append(f"  ẏ = {gy}\n")
            self.output.append(f"Jacobiano J(x,y) =\n{J}\n")

            equilibria = []
            for s in sols:
                xeq, yeq = float(s[self.x]), float(s[self.y])
                Jxy = np.array(J.subs({self.x: xeq, self.y: yeq})).astype(float)
                tipo, tr, det, disc, vals = self._clasificar_equilibrio(Jxy)
                equilibria.append((xeq, yeq, tipo, tr, det, disc, vals))

                # color por tipo
                if "Silla" in tipo:
                    color = "black"
                elif "estable" in tipo:
                    color = "green"
                elif "inestable" in tipo:
                    color = "red"
                elif "Centro" in tipo:
                    color = "orange"
                else:
                    color = "gray"

                # dibujar punto y etiqueta
                self.ax.plot(xeq, yeq, marker="o", color=color, ms=10, mec="k", mew=0.8)
                self.ax.text(xeq + 0.08, yeq, tipo.split()[0], fontsize=9, color=color, weight="bold")

            # --- trayectorias siempre ---
            rng = np.random.default_rng(1)
            for _ in range(ntraj):
                x0 = rng.uniform(x_min, x_max)
                y0 = rng.uniform(y_min, y_max)
                xs, ys = self._rk4(fvec, x0, y0, TMAX, DT)
                self.ax.plot(xs, ys, lw=1.0, alpha=0.8)

            self.ax.set_xlim(x_min, x_max)
            self.ax.set_ylim(y_min, y_max)
            self.ax.set_xlabel("x")
            self.ax.set_ylabel("y")
            self.ax.grid(True, linestyle="--", alpha=0.4)
            self.canvas.draw()

            if equilibria:
                self.output.append("Equilibrios y clasificación local:\n")
                for (xeq, yeq, tipo, tr, det, disc, vals) in equilibria:
                    self.output.append(f"(x*, y*) = ({xeq:.3f}, {yeq:.3f})")
                    self.output.append(f"  trJ={tr:.3f}, detJ={det:.3f}, Δ={disc:.3f}")
                    self.output.append(f"  tipo: {tipo}")
                    self.output.append(f"  autovalores: {', '.join(f'{v:.3f}' for v in vals)}\n")
            else:
                self.output.append("No se hallaron equilibrios.\n")

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FaseNoLineal2DWindow()
    window.show()
    sys.exit(app.exec())
