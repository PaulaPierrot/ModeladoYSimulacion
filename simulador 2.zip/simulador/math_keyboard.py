from PyQt6.QtWidgets import QWidget, QGridLayout, QPushButton

class MathKeyboard(QWidget):
    def __init__(self, insert_callback):
        super().__init__()
        self.layout = QGridLayout(self)
        self.insert_callback = insert_callback

        botones = [
            ("+", 0, 0), ("-", 0, 1), ("*", 0, 2), ("/", 0, 3),
            ("^", 1, 0), ("sqrt", 1, 1), ("ln", 1, 2), ("exp", 1, 3),
            ("sin", 2, 0), ("cos", 2, 1), ("tan", 2, 2), ("π", 2, 3),
            ("e", 3, 0), ("x", 3, 1), ("(", 3, 2), (")", 3, 3),
        ]

        for texto, fila, col in botones:
            boton = QPushButton(texto)
            boton.setFixedSize(70, 40)
            boton.clicked.connect(lambda checked, t=texto: self.insert_callback(t))
            self.layout.addWidget(boton, fila, col)
